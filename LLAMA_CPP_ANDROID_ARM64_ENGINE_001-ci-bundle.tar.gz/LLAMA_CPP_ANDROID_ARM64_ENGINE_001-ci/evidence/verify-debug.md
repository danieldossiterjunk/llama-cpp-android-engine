# ELF verification against APK Builder 0.4.0 native-prebuilt rules

- Rules file: `apkbuilder-004-native-prebuilt.json` (extension version 1)
- Project min_sdk assumed: 28
- System stub libraries: /usr/local/lib/android/sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/28
- **Overall: PASS**

## Bundle

| Check | Status | Detail |
|---|---|---|
| LIBRARY_COUNT | PASS | 4 libraries (limit 16) |
| NO_DEPENDENCY_CYCLE | PASS | load order (dependencies first): libggml-base.so -> libggml-cpu.so -> libggml.so -> libllama.so |
| LIBCXX_SHARED_NEEDED | INFO | no library needs libc++_shared.so |
| UNDEFINED_SYMBOLS_RESOLVE | PASS | every non-weak undefined symbol is provided by a DT_NEEDED library (system stubs from /usr/local/lib/android/sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/28) |
| JNI_ENTRY_PRESENT | INFO | no JNI entry: these are engine libraries; APK Builder needs a JNI bridge beside them (otherwise PREBUILT_NO_JNI_ENTRY) |

## libggml-base.so

- Size: 8320304 bytes
- SHA-256: `5b05f908fccae456045d7ea98e20540acabd8fc0459fdc09cd0056c17cf37913`
- SONAME: `libggml-base.so`
- DT_NEEDED: `libm.so`, `libdl.so`, `libc.so`
- GNU build-id: `a93339fd38aaf7e29281a1967841c055cedd53b1`
- Android ident note: API 28, NDK r29 (build 14206865)
- Symbol versions needed: {"libc.so": ["LIBC"], "libdl.so": ["LIBC"], "libm.so": ["LIBC"]}
- Exported symbols: 689 (functions 689); undefined: 87; std::__ndk1 exports: 1

| Type | Offset | VirtAddr | FileSiz | MemSiz | Flags | Align |
|---|---|---|---|---|---|---|
| PHDR | 0x40 | 0x40 | 0x1f8 | 0x1f8 | R-- | 0x8 |
| LOAD | 0x0 | 0x0 | 0xdfcf0 | 0xdfcf0 | R-X | 0x4000 |
| LOAD | 0xdfcf0 | 0xe3cf0 | 0x53f0 | 0x6310 | RW- | 0x4000 |
| LOAD | 0xe50e0 | 0xed0e0 | 0x138 | 0xe50 | RW- | 0x4000 |
| DYNAMIC | 0xe43d0 | 0xe83d0 | 0x1d0 | 0x1d0 | RW- | 0x8 |
| GNU_RELRO | 0xdfcf0 | 0xe3cf0 | 0x53f0 | 0x6310 | R-- | 0x1 |
| GNU_EH_FRAME | 0x25a10 | 0x25a10 | 0x323c | 0x323c | R-- | 0x4 |
| GNU_STACK | 0x0 | 0x0 | 0x0 | 0x0 | RW- | 0x0 |
| NOTE | 0x238 | 0x238 | 0xbc | 0xbc | R-- | 0x4 |

| Check | Status | Detail |
|---|---|---|
| ELF_READABLE | PASS | ELF64 little-endian file parsed |
| ELF_MACHINE_AARCH64 | PASS | e_machine=183 (AArch64 is 183) |
| ELF_TYPE_SHARED_OBJECT | PASS | e_type=3, PT_INTERP absent |
| SIZE_WITHIN_LIMIT | PASS | 8320304 bytes (limit 50331648) |
| NAME_NOT_RESERVED | PASS | file name libggml-base.so |
| FILE_NAME_FORM | PASS | lib<name>.so with letters, digits, . _ - |
| DYNAMIC_SEGMENT | PASS | 28 dynamic entries |
| SONAME_EQUALS_FILE_NAME | PASS | SONAME='libggml-base.so', file='libggml-base.so' |
| NEEDED_PLAIN_NAMES | PASS | DT_NEEDED=['libm.so', 'libdl.so', 'libc.so'] |
| NO_RPATH_RUNPATH | PASS | RUNPATH=[] RPATH=[] |
| DEPENDENCIES_SATISFIED | PASS | libm.so -> public system library (API 21); libdl.so -> public system library (API 21); libc.so -> public system library (API 21) |
| PAGE16K_LOAD_ALIGN | PASS | PT_LOAD p_align = ['0x4000'] |
| PAGE16K_OFFSET_CONGRUENT | PASS | p_vaddr == p_offset (mod p_align) for every PT_LOAD |
| PAGE16K_NO_SHARED_PAGE | PASS | no two PT_LOAD segments share a 16 KiB page |
| PAGE16K_RELRO | PASS | GNU_RELRO end does not share its last 16 KiB page with writable data |
| NO_WRITABLE_EXECUTABLE_SEGMENT | PASS | no PT_LOAD is both writable and executable |
| NON_EXECUTABLE_STACK | PASS | PT_GNU_STACK flags RW- |
| TLS_SEGMENT | INFO | PT_TLS absent (no ELF TLS) |
| NO_TEXT_RELOCATIONS | PASS | DT_TEXTREL absent, DF_TEXTREL clear |
| SYMBOL_HASH_TABLE | PASS | DT_HASH absent, DT_GNU_HASH present |
| SECTION_HEADERS_CONSISTENT | PASS | 37 section headers; .dynamic/.dynstr/.dynsym/hash match the dynamic segment |
| ANDROID_API_LEVEL | PASS | needs API 28 (ident note 28, symbol versions 21); project min_sdk 28; builder maximum 36 |
| NO_CXX_RUNTIME_EXPORTS | PASS | no exported C++ runtime symbols (__cxa_*, _Unwind_*, operator new/delete, ...) |
| STD_TEMPLATE_EXPORTS | INFO | 1 exported std::__ndk1 symbols emitted by the library's own code (template instantiations) |

## libggml-cpu.so

- Size: 6689496 bytes
- SHA-256: `05a47764899bb33ec14fb6baa232b70f491e986b15de659acd6d2b3e022ddade`
- SONAME: `libggml-cpu.so`
- DT_NEEDED: `libggml-base.so`, `libm.so`, `libdl.so`, `libc.so`
- GNU build-id: `e8d25c47e6dc23dc408b50d4c4689b288a85a285`
- Android ident note: API 28, NDK r29 (build 14206865)
- Symbol versions needed: {"libc.so": ["LIBC"], "libdl.so": ["LIBC"], "libm.so": ["LIBC"]}
- Exported symbols: 626 (functions 554); undefined: 148; std::__ndk1 exports: 2

| Type | Offset | VirtAddr | FileSiz | MemSiz | Flags | Align |
|---|---|---|---|---|---|---|
| PHDR | 0x40 | 0x40 | 0x1f8 | 0x1f8 | R-- | 0x8 |
| LOAD | 0x0 | 0x0 | 0xfb9e0 | 0xfb9e0 | R-X | 0x4000 |
| LOAD | 0xfb9e0 | 0xff9e0 | 0x4e38 | 0x5620 | RW- | 0x4000 |
| LOAD | 0x100818 | 0x108818 | 0x128 | 0x81a98 | RW- | 0x4000 |
| DYNAMIC | 0xff770 | 0x103770 | 0x1e0 | 0x1e0 | RW- | 0x8 |
| GNU_RELRO | 0xfb9e0 | 0xff9e0 | 0x4e38 | 0x5620 | R-- | 0x1 |
| GNU_EH_FRAME | 0x2c724 | 0x2c724 | 0x234c | 0x234c | R-- | 0x4 |
| GNU_STACK | 0x0 | 0x0 | 0x0 | 0x0 | RW- | 0x0 |
| NOTE | 0x238 | 0x238 | 0xbc | 0xbc | R-- | 0x4 |

| Check | Status | Detail |
|---|---|---|
| ELF_READABLE | PASS | ELF64 little-endian file parsed |
| ELF_MACHINE_AARCH64 | PASS | e_machine=183 (AArch64 is 183) |
| ELF_TYPE_SHARED_OBJECT | PASS | e_type=3, PT_INTERP absent |
| SIZE_WITHIN_LIMIT | PASS | 6689496 bytes (limit 50331648) |
| NAME_NOT_RESERVED | PASS | file name libggml-cpu.so |
| FILE_NAME_FORM | PASS | lib<name>.so with letters, digits, . _ - |
| DYNAMIC_SEGMENT | PASS | 29 dynamic entries |
| SONAME_EQUALS_FILE_NAME | PASS | SONAME='libggml-cpu.so', file='libggml-cpu.so' |
| NEEDED_PLAIN_NAMES | PASS | DT_NEEDED=['libggml-base.so', 'libm.so', 'libdl.so', 'libc.so'] |
| NO_RPATH_RUNPATH | PASS | RUNPATH=[] RPATH=[] |
| DEPENDENCIES_SATISFIED | PASS | libggml-base.so -> bundle; libm.so -> public system library (API 21); libdl.so -> public system library (API 21); libc.so -> public system library (API 21) |
| PAGE16K_LOAD_ALIGN | PASS | PT_LOAD p_align = ['0x4000'] |
| PAGE16K_OFFSET_CONGRUENT | PASS | p_vaddr == p_offset (mod p_align) for every PT_LOAD |
| PAGE16K_NO_SHARED_PAGE | PASS | no two PT_LOAD segments share a 16 KiB page |
| PAGE16K_RELRO | PASS | GNU_RELRO end does not share its last 16 KiB page with writable data |
| NO_WRITABLE_EXECUTABLE_SEGMENT | PASS | no PT_LOAD is both writable and executable |
| NON_EXECUTABLE_STACK | PASS | PT_GNU_STACK flags RW- |
| TLS_SEGMENT | INFO | PT_TLS absent (no ELF TLS) |
| NO_TEXT_RELOCATIONS | PASS | DT_TEXTREL absent, DF_TEXTREL clear |
| SYMBOL_HASH_TABLE | PASS | DT_HASH absent, DT_GNU_HASH present |
| SECTION_HEADERS_CONSISTENT | PASS | 37 section headers; .dynamic/.dynstr/.dynsym/hash match the dynamic segment |
| ANDROID_API_LEVEL | PASS | needs API 28 (ident note 28, symbol versions 21); project min_sdk 28; builder maximum 36 |
| NO_CXX_RUNTIME_EXPORTS | PASS | no exported C++ runtime symbols (__cxa_*, _Unwind_*, operator new/delete, ...) |
| STD_TEMPLATE_EXPORTS | INFO | 2 exported std::__ndk1 symbols emitted by the library's own code (template instantiations) |

## libggml.so

- Size: 6269944 bytes
- SHA-256: `b7c562f5237a5814edd9153e7894845b03fdd96cdcae6c48cffaaaad74cd1f75`
- SONAME: `libggml.so`
- DT_NEEDED: `libggml-cpu.so`, `libggml-base.so`, `libm.so`, `libdl.so`, `libc.so`
- GNU build-id: `f8da10952167108fa9e15193f9e02859c7c6c4ea`
- Android ident note: API 28, NDK r29 (build 14206865)
- Symbol versions needed: {"libc.so": ["LIBC"], "libdl.so": ["LIBC"]}
- Exported symbols: 16 (functions 16); undefined: 70; std::__ndk1 exports: 0

| Type | Offset | VirtAddr | FileSiz | MemSiz | Flags | Align |
|---|---|---|---|---|---|---|
| PHDR | 0x40 | 0x40 | 0x1f8 | 0x1f8 | R-- | 0x8 |
| LOAD | 0x0 | 0x0 | 0x38250 | 0x38250 | R-X | 0x4000 |
| LOAD | 0x38250 | 0x3c250 | 0x3858 | 0x3db0 | RW- | 0x4000 |
| LOAD | 0x3baa8 | 0x43aa8 | 0x68 | 0xbd8 | RW- | 0x4000 |
| DYNAMIC | 0x3b578 | 0x3f578 | 0x1f0 | 0x1f0 | RW- | 0x8 |
| GNU_RELRO | 0x38250 | 0x3c250 | 0x3858 | 0x3db0 | R-- | 0x1 |
| GNU_EH_FRAME | 0x77b4 | 0x77b4 | 0x135c | 0x135c | R-- | 0x4 |
| GNU_STACK | 0x0 | 0x0 | 0x0 | 0x0 | RW- | 0x0 |
| NOTE | 0x238 | 0x238 | 0xbc | 0xbc | R-- | 0x4 |

| Check | Status | Detail |
|---|---|---|
| ELF_READABLE | PASS | ELF64 little-endian file parsed |
| ELF_MACHINE_AARCH64 | PASS | e_machine=183 (AArch64 is 183) |
| ELF_TYPE_SHARED_OBJECT | PASS | e_type=3, PT_INTERP absent |
| SIZE_WITHIN_LIMIT | PASS | 6269944 bytes (limit 50331648) |
| NAME_NOT_RESERVED | PASS | file name libggml.so |
| FILE_NAME_FORM | PASS | lib<name>.so with letters, digits, . _ - |
| DYNAMIC_SEGMENT | PASS | 30 dynamic entries |
| SONAME_EQUALS_FILE_NAME | PASS | SONAME='libggml.so', file='libggml.so' |
| NEEDED_PLAIN_NAMES | PASS | DT_NEEDED=['libggml-cpu.so', 'libggml-base.so', 'libm.so', 'libdl.so', 'libc.so'] |
| NO_RPATH_RUNPATH | PASS | RUNPATH=[] RPATH=[] |
| DEPENDENCIES_SATISFIED | PASS | libggml-cpu.so -> bundle; libggml-base.so -> bundle; libm.so -> public system library (API 21); libdl.so -> public system library (API 21); libc.so -> public system library (API 21) |
| PAGE16K_LOAD_ALIGN | PASS | PT_LOAD p_align = ['0x4000'] |
| PAGE16K_OFFSET_CONGRUENT | PASS | p_vaddr == p_offset (mod p_align) for every PT_LOAD |
| PAGE16K_NO_SHARED_PAGE | PASS | no two PT_LOAD segments share a 16 KiB page |
| PAGE16K_RELRO | PASS | GNU_RELRO end does not share its last 16 KiB page with writable data |
| NO_WRITABLE_EXECUTABLE_SEGMENT | PASS | no PT_LOAD is both writable and executable |
| NON_EXECUTABLE_STACK | PASS | PT_GNU_STACK flags RW- |
| TLS_SEGMENT | INFO | PT_TLS absent (no ELF TLS) |
| NO_TEXT_RELOCATIONS | PASS | DT_TEXTREL absent, DF_TEXTREL clear |
| SYMBOL_HASH_TABLE | PASS | DT_HASH absent, DT_GNU_HASH present |
| SECTION_HEADERS_CONSISTENT | PASS | 37 section headers; .dynamic/.dynstr/.dynsym/hash match the dynamic segment |
| ANDROID_API_LEVEL | PASS | needs API 28 (ident note 28, symbol versions 21); project min_sdk 28; builder maximum 36 |
| NO_CXX_RUNTIME_EXPORTS | PASS | no exported C++ runtime symbols (__cxa_*, _Unwind_*, operator new/delete, ...) |
| STD_TEMPLATE_EXPORTS | INFO | 0 exported std::__ndk1 symbols emitted by the library's own code (template instantiations) |

## libllama.so

- Size: 44637304 bytes
- SHA-256: `c5a94980f3ff9a381c44b424ef6694952f8fb700d2debc2abe9a3c69ae47e214`
- SONAME: `libllama.so`
- DT_NEEDED: `libggml.so`, `libggml-cpu.so`, `libggml-base.so`, `libm.so`, `libdl.so`, `libc.so`
- GNU build-id: `7e5c8352a19af52fbcb06505a2623710300091e3`
- Android ident note: API 28, NDK r29 (build 14206865)
- Symbol versions needed: {"libc.so": ["LIBC"], "libdl.so": ["LIBC"], "libm.so": ["LIBC"]}
- Exported symbols: 5316 (functions 3759); undefined: 435; std::__ndk1 exports: 771

| Type | Offset | VirtAddr | FileSiz | MemSiz | Flags | Align |
|---|---|---|---|---|---|---|
| PHDR | 0x40 | 0x40 | 0x1f8 | 0x1f8 | R-- | 0x8 |
| LOAD | 0x0 | 0x0 | 0x408170 | 0x408170 | R-X | 0x4000 |
| LOAD | 0x408170 | 0x40c170 | 0x1b278 | 0x1be90 | RW- | 0x4000 |
| LOAD | 0x4233e8 | 0x42b3e8 | 0x8c8 | 0x37e8 | RW- | 0x4000 |
| DYNAMIC | 0x41db38 | 0x421b38 | 0x200 | 0x200 | RW- | 0x8 |
| GNU_RELRO | 0x408170 | 0x40c170 | 0x1b278 | 0x1be90 | R-- | 0x1 |
| GNU_EH_FRAME | 0xfecdc | 0xfecdc | 0xbd8c | 0xbd8c | R-- | 0x4 |
| GNU_STACK | 0x0 | 0x0 | 0x0 | 0x0 | RW- | 0x0 |
| NOTE | 0x238 | 0x238 | 0xbc | 0xbc | R-- | 0x4 |

| Check | Status | Detail |
|---|---|---|
| ELF_READABLE | PASS | ELF64 little-endian file parsed |
| ELF_MACHINE_AARCH64 | PASS | e_machine=183 (AArch64 is 183) |
| ELF_TYPE_SHARED_OBJECT | PASS | e_type=3, PT_INTERP absent |
| SIZE_WITHIN_LIMIT | PASS | 44637304 bytes (limit 50331648) |
| NAME_NOT_RESERVED | PASS | file name libllama.so |
| FILE_NAME_FORM | PASS | lib<name>.so with letters, digits, . _ - |
| DYNAMIC_SEGMENT | PASS | 31 dynamic entries |
| SONAME_EQUALS_FILE_NAME | PASS | SONAME='libllama.so', file='libllama.so' |
| NEEDED_PLAIN_NAMES | PASS | DT_NEEDED=['libggml.so', 'libggml-cpu.so', 'libggml-base.so', 'libm.so', 'libdl.so', 'libc.so'] |
| NO_RPATH_RUNPATH | PASS | RUNPATH=[] RPATH=[] |
| DEPENDENCIES_SATISFIED | PASS | libggml.so -> bundle; libggml-cpu.so -> bundle; libggml-base.so -> bundle; libm.so -> public system library (API 21); libdl.so -> public system library (API 21); libc.so -> public system library (API 21) |
| PAGE16K_LOAD_ALIGN | PASS | PT_LOAD p_align = ['0x4000'] |
| PAGE16K_OFFSET_CONGRUENT | PASS | p_vaddr == p_offset (mod p_align) for every PT_LOAD |
| PAGE16K_NO_SHARED_PAGE | PASS | no two PT_LOAD segments share a 16 KiB page |
| PAGE16K_RELRO | PASS | GNU_RELRO end does not share its last 16 KiB page with writable data |
| NO_WRITABLE_EXECUTABLE_SEGMENT | PASS | no PT_LOAD is both writable and executable |
| NON_EXECUTABLE_STACK | PASS | PT_GNU_STACK flags RW- |
| TLS_SEGMENT | INFO | PT_TLS absent (no ELF TLS) |
| NO_TEXT_RELOCATIONS | PASS | DT_TEXTREL absent, DF_TEXTREL clear |
| SYMBOL_HASH_TABLE | PASS | DT_HASH absent, DT_GNU_HASH present |
| SECTION_HEADERS_CONSISTENT | PASS | 37 section headers; .dynamic/.dynstr/.dynsym/hash match the dynamic segment |
| ANDROID_API_LEVEL | PASS | needs API 28 (ident note 28, symbol versions 21); project min_sdk 28; builder maximum 36 |
| NO_CXX_RUNTIME_EXPORTS | PASS | no exported C++ runtime symbols (__cxa_*, _Unwind_*, operator new/delete, ...) |
| STD_TEMPLATE_EXPORTS | INFO | 771 exported std::__ndk1 symbols emitted by the library's own code (template instantiations) |
